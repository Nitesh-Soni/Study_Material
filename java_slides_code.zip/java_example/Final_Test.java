// final class example

final class Final_Base{
		final void display(){
			System.out.println("final method display()...");
		}
	
}
public class Final_Test{
		public static void main(String args[]){
		Final_Base final_obj = new Final_Base();
		final_obj.display();
		final int x = 200 ;
		System.out.println("Value of final variable is "+ x);
		 //x = 400; --> This will give an error as x is a final variable.

		}
}