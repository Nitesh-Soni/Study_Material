interface Inter{
	int add(int x, int y);
	int mul(int x, int y);
}

class InterImpl implements Inter{
	@Override
	public int add(int x, int y) {
	return x + y;
	}
	@Override
	public int mul(int x, int y) {
	return x * y;
	}
}

public class InterfaceDemo {
	public static void main(String[] args) {
	InterImpl obj = new InterImpl();
	System.out.println(obj.add(20, 30));
	System.out.println(obj.mul(200, 30));
	}
}