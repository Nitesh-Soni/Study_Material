// package com.skillspeed;
import java.util.*;
public class HashMapDemo{
	public static void main (String args[]){
	HashMap<String, Double> hm = new HashMap<String,Double>();
	// Put elements to the map
	hm.put("Ronald", new Double(3434.00));
	hm.put("Steven", new Double (1235.22));
	hm.put("Thomas", new Double(1378.00));
	hm.put("Robert", new Double(19.08));
	//hm.put(null, new Double (20.30));
	//Get a set of the entries.
	Set<Map.Entry<String, Double>> set = hm.entrySet();
	// Display the set.
	for(Map.Entry<String, Double> me : set){
	if (me.getValue() > 1000.0){
	System.out.print(me.getKey() + ": ");
	System.out.println(me.getValue());
	}
	}
	System.out.println();
	// Deposit 1000 into John Doe's account.
	double balance = hm.get("Robert");
	hm.put("Robert", balance + 4000);
	System.out.println("Robert's new balance: "+hm.get("Robert"));
}
}