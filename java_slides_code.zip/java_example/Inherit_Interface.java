interface Inter1{
		int add(int x, int y);
		int mul(int x, int y);
}

interface Inter2 extends Inter1{
		double sqrt (double x);
}

class InterImpl1 implements Inter2{
		//Override	
		public int add(int x, int y) {
		return x + y;
		}
		//Override
		public int mul(int x, int y) {
		return x * y;
		}

		// Override
		public double sqrt(double x) {
		return Math.sqrt(x);
		}
}
public class Inherit_Interface {
	public static void main(String[] args) {
	InterImpl1 Obj = new InterImpl1();
	System.out.println("Square root is "+Obj.sqrt(36));
	}
}