// constructor example 

public class ClassPenConstructor{
		String made_up_of;
		String pen_color ;
		String company;
	
		public ClassPenConstructor(){

			made_up_of = "Copper";
			pen_color = "green";
			company = "Royal green";
		}
		public static void main(String args[]){}
}
		