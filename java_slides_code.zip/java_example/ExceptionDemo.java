public class ExceptionDemo {
	public static void main(String[] args) {
	try{
		int x = 50, y = 0;
		int z = x / y;
		System.out.println("Result is "+z);
	}
	catch (ArithmeticException ex){
		System.out.println("Exception is "+ex);
	}
	
	finally{
		System.out.println("In the finally block...");
	}
	}
}