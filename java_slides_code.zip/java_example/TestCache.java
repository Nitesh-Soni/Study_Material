 class CachePerson{
	private Person person;
	public void addPerson(Person person)
	{this.person=person;}
	public Person getPerson()
	{return this.person;}
}

 class CacheName
{
private String name;
public void addName(String name)
{this.name=name;}
public String getName()
{return this.name;}
}
 class CacheAny<T>{
	private T t;
	public void add(T t){
	this.t=t;
	}
	public T get(){
	return this.t;
	}
}
class Person{}

 class TestCache{
	public static void main(String []s){
	CacheName cn=new CacheName();
	CachePerson cp=new CachePerson();
	Person p2 = new Person();
	CacheAny<String> can1=new CacheAny<String>();
	CacheAny<Person> can2=new CacheAny<Person>();
	can1.add("Jane");
	can2.add(p2);//assume that we have a person object p2
}
}