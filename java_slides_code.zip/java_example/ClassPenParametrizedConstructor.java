//  parametrized constructor  example 

public class ClassPenParametrizedConstructor{
		String made_up_of;
		String pen_color ;
		String company;
	
		public ClassPenParametrizedConstructor(String made ,String color , String comp){

			made_up_of = made;
			pen_color = color;
			company = comp;
		}
		
		public static void main(String args[]){

		ClassPenParametrizedConstructor  p ;
		p = new ClassPenParametrizedConstructor("silver","white","silver oak");
		}		

		
}
