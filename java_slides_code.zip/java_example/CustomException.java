class MyException extends Exception{
	public MyException(String message){
	super(message);
	}
}

public class CustomException {

	public static void main(String args[]) throws Exception{
	CustomException exceptionDemo = new CustomException();
	try{
		exceptionDemo.displayNumbers();
	}
	catch (MyException ex){
		System.out.println("Exception is "+ex);
	}
}

public void displayNumbers() throws MyException{
	for(int i=0;i<10;i++)	{
		System.out.println("i= "+i);
	if(i==6){
		throw new MyException("Throwing the exception using Custom exception MyException...Numbe is 6...");
	}
	}
	}
}