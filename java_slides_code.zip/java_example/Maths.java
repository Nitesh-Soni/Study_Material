package com.skillspeed;

public class Maths{
	public int add(int x, int y) {
	return x + y;
	}

	public int sub(int x, int y) {
	return x - y;
	}
	public int mul(int x, int y) {
	return x * y;
	}
	public int div (int x, int y) {
	return x / y;
	}
	public double sqrt(double x) {
	return Math.sqrt(x);
	}
	public static void main(String[] args) {
	}
}