public class ClassPen{
		String made_up_of;
		String pen_color ;
		String company;
	
		void toWrite(){
			System.out.println("Pen is used for writing....");
		}
	
		void toGift(){
			System.out.println("pen is used for gifting...");
		}
		
		void asShowPiece(){
			System.out.println("Key as a show piece");
		}

		public static void main(String args[]){
		}
}