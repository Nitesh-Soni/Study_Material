// Method overriding Example

class Base{
		void display(){
			System.out.println("In the base class dispplay() method..");
		}
}

class Child extends Base{
		void display(){
			System.out.println("In the child display() method ....");
		}
}

public class Inheritance{
		public static void main(String args[]){
		Child c1 = new Child();
		c1.display(); //--> Since there is child class display method is
		//available, it calls child class display() method only

		}
}