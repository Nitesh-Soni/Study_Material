public class ThrowsException {
	int div (int x, int y) throws ArithmeticException{
	return x / y;
	}
	public static void main(String[] args) {
	try{
		int x = 20, y = 0;
		ThrowsException e1 = new ThrowsException();
		int result = e1.div(x, y);
		System.out.println("Result is "+result);
	}
	catch (ArithmeticException ex){
		System.out.println("Exception is "+ex);
	}
	}
}