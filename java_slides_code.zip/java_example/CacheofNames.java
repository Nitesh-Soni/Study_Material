public class CacheofNames{
	private String name;
	public void addName(String name){
		this.name=name;
	}
	public String getName(){
	return this.name;
	}
	public static void main(String args[]){}
}