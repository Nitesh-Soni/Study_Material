// abstract class 

abstract class BaseClass{
		abstract int add (int x, int y);
}

public class Abstract_Class extends BaseClass{
		int add(int x, int y) {
		return x + y;
}
	
	public static void main(String[] args) {
	Abstract_Class abs_obj = new Abstract_Class();
	System.out.println(abs_obj.add (20, 30));
	}
}