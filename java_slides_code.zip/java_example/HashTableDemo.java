package com.skillspeed;
import java.util.*;
	public class HashTableDemo {
	public static void main(String[] args) {
	Hashtable<String, Double> balance = new Hashtable<String, Double>();
	Enumeration<String> names;
	String str;
	double bal;
	balance.put("Ronald", 5434.00);
	balance.put("Steven", 5323.22);
	balance.put("Thomas", 1378.00);
	balance.put("Joseph", 10099.22);
	balance.put("Robert", -19.08);
	// balance.put(null, 100.20);
	// Show all balances in hashtable.
	names = balance.keys();
	while(names.hasMoreElements()) {
	//Displays the records whose balance is greater than 5000.00
	str = names.nextElement();
	bal = balance.get(str).doubleValue();
	if (bal > 5000) {
		System.out.println(str +" balance is " + bal);
	}
	}
	System.out.println();
		// Deposit 1,000 into Joseph's account.
		bal = balance.get("Steven");
		balance.put("Joseph", bal+7000);
		System.out.println("Joseph's new balance: " + balance.get("Joseph"));
	}
}