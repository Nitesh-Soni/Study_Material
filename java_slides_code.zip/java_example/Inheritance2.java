// Constructor in Inheritance

class Base
	{
	Base(){
		System.out.println("Base class constructor..");
	}
}

class Child extends Base{
	Child (){
		System.out.println("Child class constructor..");
	}
	void display(){
		System.out.println("Display() method in the derived class..");
	}
}

public class Inheritance2 {
	public static void main(String[] args) {
	Child c1 = new Child();
	c1.display();
	}
}