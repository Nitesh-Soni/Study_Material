import java.util.Scanner;
class Car{
	void features(){
		System.out.println("Power steering, power windows..");
	}
}

class Audi extends Car{
	void features(){
		super.features();
		System.out.println("bhp, ride quality, prestige, power,safety, speed, 1798cc, 12.32kmpl");	
	}
}

class BMW extends Car{
	void features(){
		super.features();
		System.out.println("x1 power, bhp ride, quality space, 1995cc, 14.44kmpl");
	}
}

public class Inheritance3 {
	public static void main (String args[]){
	Car c1 = null;
	Scanner sc = new Scanner(System.in);
	System.out.println("Please enter which car do you want to see (Audi/BMW)");
	String car_type = sc.next();
	if (car_type.equalsIgnoreCase("Audi"))
	c1 = new Audi();
	else if (car_type.equalsIgnoreCase("BMW"))
	c1 = new BMW();
	c1.features();
	}
}