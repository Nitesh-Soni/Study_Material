import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
public class FileCopy {
	public static void main(String[] args) throws IOException{
	File file = new File("file.txt");
	FileInputStream fis=null;
	FileOutputStream fout=null;
	int counter = 0;
	try {
		fis = new FileInputStream(file);
		fout = new FileOutputStream ("output_test.txt");
		int content;
		while ((content = fis.read()) != -1) {
		fout.write(content);
		++counter;
		}
		System.out.println("File copied successfully...");					
		System.out.println("Number of characters in a file are "+counter);
		} catch (IOException e) {
			e.printStackTrace();
		}
		fis.close();
		fout.close();
}
}