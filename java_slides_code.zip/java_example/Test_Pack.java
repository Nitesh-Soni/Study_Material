package test_package;

import com.skillspeed.Maths;

public class Test_Pack {
	public static void main(String[] args) {
	Maths maths_obj = new Maths();
	System.out.println("add : " + maths_obj.add(30, 40));
	System.out.println("Sub : " + maths_obj.sub(130, 40));
	System.out.println("Multiply : " + maths_obj.mul(30, 40));
	System.out.println("Square root : " + maths_obj.sqrt(144));
	}
}