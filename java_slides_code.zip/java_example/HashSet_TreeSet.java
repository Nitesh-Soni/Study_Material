package com.skillspeed;
import java.util.*;

public class HashSet_TreeSet{
	public static void main(String args[]){
		HashSet hs = new HashSet();
		hs.add(1);
		hs.add(1);
		hs.add(2);
		hs.add(3);
		hs.add(4);
	System.out.println(hs);
	Iterator it = hs.iterator();
	while (it.hasNext()){
	int i = (Integer) it.next();
		System.out.println(i);
	}
	}
}