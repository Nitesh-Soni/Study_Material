// static example

public class Static1{
		static int x = 200 ;
		static void display(){
			System.out.println("In the static function display()");
		}
		
		static{
			System.out.println("this is a static block");
		}
		
		public static void main(String args[]){
			System.out.println(Static1.x);
		Static1.display();
		}
}